import java.net.URI;
import java.io.PrintWriter;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.Calendar;
import java.time.Instant;

public class Downloader {

	private static Calendar cal = Calendar.getInstance (java.util.TimeZone.getTimeZone("UTC"));
	private static final int project_start = 1640997300;

	public static void main (String[] args) throws IOException {
	
		while (!isProjectEnd()) {
			try {
				getMETAR ("EDDN"); 
				getMETAR ("NZAA");
			} catch (Exception e) {
				e.printStackTrace();
				System.exit (-1); 
			}
			QBackup();
			WaitThread();
		}
	}
	
	private static boolean isProjectEnd() {
		return (UNIX_TimeStamp() > 1672531199);
	}

	public static void WaitThread () {
		try{
			int sleepTime = (int) (UNIX_TimeStamp()-project_start);
			sleepTime %= 3600; 
			sleepTime = 3600 - sleepTime;
			System.err.printf("[INFO]: (WaitThread) sleeping for %d sec.\n", sleepTime);
			Thread.sleep(sleepTime*1000); 
		}catch (Exception e) {
			e.printStackTrace();
		}	
	}
	
	public static void QBackup () {
		if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY) {
			System.err.printf ("[INFO]: Regular Monday Backup @%d\n", UNIX_TimeStamp());
			System.exit (0);
		} else if ( UNIX_TimeStamp () >= 1672531199) {
			System.err.println("[WARN]: Project ended, Backing up\n"); 
			System.exit (-2147483648);
		} else {
			System.err.printf ("[INFO]: (%d) No Backup necessary\n", UNIX_TimeStamp());
			return;
		}
	}

	public static long UNIX_TimeStamp () {
		return Instant.now (java.time.Clock.systemUTC()).getEpochSecond();	
	}

	public static void getMETAR (String Airport) throws Exception { 
		String response = ""; 
		Scanner sc = new Scanner (
			new URI ("https://tgftp.nws.noaa.gov/weather/current/"+Airport+".html")
			.toURL().openStream()
		);
		
		while (sc.hasNext()) 
			response += sc.nextLine();
		int beginIndex = response.lastIndexOf(Airport),
		    endIndex = response.indexOf("<", beginIndex);
		String Metar = response.substring (beginIndex, endIndex);
		System.err.printf ("[INFO]: METAR %s\n", Metar); 
		PrintWriter pw = getFile(Airport);
		pw.println(Metar); 
		pw.close();
	}


	public static PrintWriter getFile (String Airport) throws Exception {
		String FileName = "data.raw-"+getMonthAb()+"-"+Airport+".txt";
		File data = new File ("/home/akb1152/Projects/metar-data/data/"+FileName);
		if (!data.exists()) createFile(data);
		String Content = "";		
		Scanner sc = new Scanner(data, "utf-8");	
		while (sc.hasNextLine())	
			Content += sc.nextLine();
		sc.close();
		Content = Content.replace( Airport, "\n"+Airport);
		
		PrintWriter pw = new PrintWriter (data, "utf-8");
		pw.println (Content); 
		return pw; 
	}

	public static void createFile (File f) throws IOException, InterruptedException{
		String $cmd = "echo \"\"| tee "+ f.getAbsolutePath();
		System.out.println("————Start sh code––––");
		ProcessBuilder pb = new ProcessBuilder();
		pb.command("bash", "-c", $cmd);
		Process p = pb.start();
		p.waitFor();
		System.out.println("––DONE ($? == 0x"+Integer.toHexString(p.exitValue())+") ––");
	}
	
	public static String getMonthAb () {
		int index = cal.get(Calendar.MONTH);
		String[] abbr = 
		{"0-jan", "1-feb", "2-mar", "3-apr", "4-may", "5-jun",
		 "6-jul", "7-aug", "8-sep", "9-oct", "A-nov", "B-dec"};
		return abbr[index]; 
	}
}
