#include <stddef.h>
#include <time.h>

int main () {
long long UNIX = (long long) time(NULL); // get Current UNIX;
if ( 1672531199 <= UNIX ) 
	return 1;
else 
	return 0; 
}
