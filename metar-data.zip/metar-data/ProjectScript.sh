#! /bin/bash

path="$HOME/Projects/metar-data";
alias ProjectEnded='$path/ProjectEnded';
wait=127;
while (( wait != 0 )); do
	java "$path/ProjectWaiter.java";	
	wait=$?;
	sleep $wait; 
done
isProjectEnded=0;
isBackup=0;
while (( isProjectEnded == 0 )); do 
	java "$path/Downloader.java";
	isBackup=$?;
	if (( isBackup == 0 )); then 
		commit "Backup";
	elif (( isBackup == -2147483648 )); then
		commit "End";
	fi; 
	ProjectEnded;
	isProjectEnded=$?;
done; 
commit () {
	cd "$HOME/Projects/metar\-data/" || exit;
	git add all;
	git commit -m "$1"; 
	token=$(cat ./.token);
	git push --repo "https://akb1152:$token@github.com/metar-data.git";
	return $?;
}