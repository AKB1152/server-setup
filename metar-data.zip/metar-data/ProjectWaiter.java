import java.time.Instant;

public class ProjectWaiter {
	
	public static void main (String[] args) {
		final int project_start = 1640997300;
		int now = (int)Instant.now (java.time.Clock.systemUTC()).getEpochSecond();
		System.exit ((project_start > now)? (project_start - now) : 0);
	}
}
